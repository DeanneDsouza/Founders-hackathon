# Vibe Navigator — Setup Guide

## What This App Does
An AI-powered route planner that generates mood-based navigation routes (calm, scenic, fast, fun, quiet).

---

## Step 1 — Install Node.js

Download and install **Node.js v18 or later** from:  
👉 https://nodejs.org/

Verify it works by opening a terminal and running:
```
node -v
npm -v
```

---

## Step 2 — Install Project Dependencies

Open a terminal in the project folder (where `package.json` is) and run:
```
npm install
```

---

## Step 3 — Get Your Free API Key (Only One Needed!)

This app uses **one API** — the Anthropic API. It's free to start.

### Get your Anthropic API key:
1. Go to 👉 https://console.anthropic.com
2. Sign up (no credit card required — free credits included on signup)
3. Navigate to **API Keys** in the dashboard
4. Click **Create Key** and copy it

### Add it to the project:
Open `.env` in the project root and replace the placeholder:

```
VITE_ANTHROPIC_API_KEY="paste_your_key_here"
```

Keep the quotes. That's the only configuration needed.

---

## Step 4 — Run the App

```
npm run dev
```

Open your browser to: **http://localhost:8080**

---

## Free Tier Info

New Anthropic accounts come with free credits — plenty for testing.  
The app uses `claude-haiku-4-5` (the fastest, cheapest model) so credits stretch far.

---

## Other Useful Commands

| Command | What it does |
|---|---|
| `npm run dev` | Start development server |
| `npm run build` | Build for production |
| `npm run preview` | Preview production build |
| `npm test` | Run unit tests |

---

## Tech Stack

- **React 18** + **TypeScript** + **Vite**
- **Tailwind CSS** + **shadcn/ui**
- **Leaflet** — free open-source maps (no key needed)
- **Anthropic Claude Haiku** — AI route generation (free tier)
- **Framer Motion** — animations
