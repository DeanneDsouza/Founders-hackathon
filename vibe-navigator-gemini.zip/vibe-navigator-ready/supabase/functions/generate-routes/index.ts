import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { startLocation, destination, vibe, customVibe, transport } = await req.json();

    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) throw new Error("LOVABLE_API_KEY not configured");

    const vibeDescription = customVibe || vibe || "calm";
    const transportMode = transport || "walking";

    const systemPrompt = `You are VibeRoute AI — an expert at creating emotionally-optimized navigation routes. 
You generate creative, realistic walking/biking/driving routes based on the user's mood.

CRITICAL: You MUST respond with valid JSON only. No markdown, no explanation, just a JSON array.

The JSON must be an array of 3 route objects, each with this exact structure:
{
  "id": "unique-string",
  "name": "Creative Route Name",
  "description": "2-3 sentence description of the route experience",
  "vibeExplanation": "1-2 sentences explaining why this route matches the mood",
  "distance": "X.X km",
  "duration": "XX min",
  "attractions": ["Place 1", "Place 2", "Place 3"],
  "playlist": { "name": "Playlist Name", "genre": "Genre", "emoji": "🎵" },
  "startLat": number,
  "startLng": number,
  "waypoints": [[lat, lng], [lat, lng], ...],
  "endLat": number,
  "endLng": number
}

For waypoints, generate 6-10 realistic coordinate pairs that form a plausible route between start and end.
Use real-world coordinates for the city/area mentioned. If no specific city is mentioned, use New York City.
Make routes distinct — different paths, different vibes within the mood, different durations.

Vibe mappings:
- calm → quiet streets, parks, gardens, waterfront, low traffic
- scenic → viewpoints, landmarks, water views, photo spots  
- fast → direct routes, main roads, efficient paths
- fun → lively streets, entertainment, cafes, street art, markets
- quiet → residential areas, hidden paths, minimal crowds

For playlists:
- calm → lo-fi, ambient, classical
- scenic → indie, acoustic, cinematic
- fast → EDM, electronic, drum & bass
- fun → pop, funk, dance, party
- quiet → ambient, minimal, nature sounds`;

    const userPrompt = `Generate 3 ${vibeDescription} routes for ${transportMode} from "${startLocation}" to "${destination}".
Return ONLY a JSON array, no other text.`;

    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-3-flash-preview",
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: userPrompt },
        ],
        temperature: 0.8,
      }),
    });

    if (!response.ok) {
      if (response.status === 429) {
        return new Response(JSON.stringify({ error: "Rate limited — please try again in a moment." }), {
          status: 429,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      if (response.status === 402) {
        return new Response(JSON.stringify({ error: "AI credits exhausted. Please add funds." }), {
          status: 402,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      const errorText = await response.text();
      console.error("AI gateway error:", response.status, errorText);
      throw new Error(`AI gateway error: ${response.status}`);
    }

    const data = await response.json();
    let content = data.choices?.[0]?.message?.content || "";

    // Strip markdown code fences if present
    content = content.replace(/```json\n?/g, "").replace(/```\n?/g, "").trim();

    let routes;
    try {
      routes = JSON.parse(content);
    } catch (parseError) {
      console.error("Failed to parse AI response:", content);
      throw new Error("AI returned invalid JSON");
    }

    // Transform into the format the frontend expects
    const formattedRoutes = routes.map((r: any, i: number) => ({
      id: r.id || `route-${i}`,
      name: r.name,
      description: r.description,
      vibeExplanation: r.vibeExplanation,
      distance: r.distance,
      duration: r.duration,
      attractions: r.attractions || [],
      coordinates: r.waypoints || [[r.startLat, r.startLng], [r.endLat, r.endLng]],
      playlist: r.playlist || { name: "Vibe Mix", genre: "Mixed", emoji: "🎵" },
    }));

    return new Response(JSON.stringify({ routes: formattedRoutes }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e) {
    console.error("generate-routes error:", e);
    return new Response(
      JSON.stringify({ error: e instanceof Error ? e.message : "Unknown error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
