export type Vibe = "calm" | "scenic" | "fast" | "fun" | "quiet";
export type Transport = "walking" | "bike" | "car" | "transit";

export interface RouteOption {
  id: string;
  name: string;
  description: string;
  vibeExplanation: string;
  distance: string;
  duration: string;
  attractions: string[];
  coordinates: [number, number][];
  playlist: { name: string; genre: string; emoji: string };
}

export interface AppState {
  screen: "input" | "routes" | "preview";
  startLocation: string;
  destination: string;
  vibe: Vibe | null;
  customVibe: string;
  transport: Transport;
  routes: RouteOption[];
  selectedRoute: RouteOption | null;
  isLoading: boolean;
  userCoords: [number, number] | null;
}
