import { RouteOption, Vibe, Transport } from "./types";

const GEMINI_API_KEY = import.meta.env.VITE_GEMINI_API_KEY;

export async function generateAIRoutes(
  startLocation: string,
  destination: string,
  vibe: Vibe | null,
  customVibe: string,
  transport: Transport
): Promise<RouteOption[]> {
  if (!GEMINI_API_KEY) {
    throw new Error("Missing VITE_GEMINI_API_KEY in .env file");
  }

  const vibeDescription = customVibe || vibe || "calm";
  const transportMode = transport || "walking";

  const prompt = `You are VibeRoute AI — an expert at creating emotionally-optimized navigation routes.
You generate creative, realistic walking/biking/driving routes based on the user's mood.

CRITICAL: You MUST respond with valid JSON only. No markdown, no explanation, just a JSON array.

The JSON must be an array of 3 route objects, each with this exact structure:
{
  "id": "unique-string",
  "name": "Creative Route Name",
  "description": "2-3 sentence description of the route experience",
  "vibeExplanation": "1-2 sentences explaining why this route matches the mood",
  "distance": "X.X km",
  "duration": "XX min",
  "attractions": ["Place 1", "Place 2", "Place 3"],
  "playlist": { "name": "Playlist Name", "genre": "Genre", "emoji": "🎵" },
  "startLat": number,
  "startLng": number,
  "waypoints": [[lat, lng], [lat, lng], ...],
  "endLat": number,
  "endLng": number
}

For waypoints, generate 6-10 realistic coordinate pairs that form a plausible route between start and end.
Use real-world coordinates for the city/area mentioned. If no specific city is mentioned, use New York City.
Make routes distinct — different paths, different vibes within the mood, different durations.

Vibe mappings:
- calm → quiet streets, parks, gardens, waterfront, low traffic
- scenic → viewpoints, landmarks, water views, photo spots
- fast → direct routes, main roads, efficient paths
- fun → lively streets, entertainment, cafes, street art, markets
- quiet → residential areas, hidden paths, minimal crowds

For playlists:
- calm → lo-fi, ambient, classical
- scenic → indie, acoustic, cinematic
- fast → EDM, electronic, drum & bass
- fun → pop, funk, dance, party
- quiet → ambient, minimal, nature sounds

Generate 3 ${vibeDescription} routes for ${transportMode} from "${startLocation}" to "${destination}".
Return ONLY a JSON array, no other text.`;

  const response = await fetch(
    `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${GEMINI_API_KEY}`,
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        contents: [{ parts: [{ text: prompt }] }],
        generationConfig: { temperature: 0.8, maxOutputTokens: 2000 },
      }),
    }
  );

  if (!response.ok) {
    const err = await response.json().catch(() => ({}));
    if (response.status === 400) throw new Error("Invalid Gemini API key. Check your .env file.");
    if (response.status === 429) throw new Error("Rate limited — please wait a moment and try again.");
    throw new Error(err?.error?.message || `API error: ${response.status}`);
  }

  const data = await response.json();
  let content = data.candidates?.[0]?.content?.parts?.[0]?.text || "";

  content = content.replace(/```json\n?/g, "").replace(/```\n?/g, "").trim();

  let routes: any[];
  try {
    routes = JSON.parse(content);
  } catch {
    throw new Error("AI returned invalid JSON — please try again.");
  }

  return routes.map((r: any, i: number) => ({
    id: r.id || `route-${i}`,
    name: r.name,
    description: r.description,
    vibeExplanation: r.vibeExplanation,
    distance: r.distance,
    duration: r.duration,
    attractions: r.attractions || [],
    coordinates: r.waypoints || [[r.startLat, r.startLng], [r.endLat, r.endLng]],
    playlist: r.playlist || { name: "Vibe Mix", genre: "Mixed", emoji: "🎵" },
  }));
}
