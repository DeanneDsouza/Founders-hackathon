import { useState, useCallback } from "react";
import { AnimatePresence } from "framer-motion";
import InputScreen from "@/components/InputScreen";
import RoutesScreen from "@/components/RoutesScreen";
import PreviewScreen from "@/components/PreviewScreen";
import { Vibe, Transport, RouteOption } from "@/lib/types";
import { generateAIRoutes } from "@/lib/api";
import { toast } from "sonner";

const vibes: Vibe[] = ["calm", "scenic", "fast", "fun", "quiet"];

export default function Index() {
  const [screen, setScreen] = useState<"input" | "routes" | "preview">("input");
  const [startLocation, setStartLocation] = useState("");
  const [destination, setDestination] = useState("");
  const [vibe, setVibe] = useState<Vibe | null>(null);
  const [customVibe, setCustomVibe] = useState("");
  const [transport, setTransport] = useState<Transport>("walking");
  const [routes, setRoutes] = useState<RouteOption[]>([]);
  const [selectedRoute, setSelectedRoute] = useState<RouteOption | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const detectLocation = useCallback(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          setStartLocation(`${pos.coords.latitude.toFixed(4)}, ${pos.coords.longitude.toFixed(4)}`);
          toast.success("Location detected!");
        },
        () => {
          setStartLocation("Times Square, New York");
          toast.info("Using default location");
        }
      );
    } else {
      setStartLocation("Times Square, New York");
    }
  }, []);

  const generate = useCallback(async () => {
    setIsLoading(true);
    try {
      const aiRoutes = await generateAIRoutes(
        startLocation,
        destination,
        vibe,
        customVibe,
        transport
      );
      setRoutes(aiRoutes);
      setScreen("routes");
    } catch (err: any) {
      console.error("Route generation failed:", err);
      toast.error(err.message || "Failed to generate routes. Please try again.");
    } finally {
      setIsLoading(false);
    }
  }, [startLocation, destination, vibe, customVibe, transport]);

  const surpriseMe = useCallback(async () => {
    const randomVibe = vibes[Math.floor(Math.random() * vibes.length)];
    const surpriseStart = "Times Square, New York";
    const surpriseDestinations = [
      "Brooklyn Bridge, New York",
      "Central Park, New York",
      "High Line, New York",
      "DUMBO, Brooklyn",
      "Greenwich Village, New York",
      "Williamsburg, Brooklyn",
    ];
    const surpriseDest = surpriseDestinations[Math.floor(Math.random() * surpriseDestinations.length)];

    setStartLocation(surpriseStart);
    setDestination(surpriseDest);
    setVibe(randomVibe);
    setIsLoading(true);

    try {
      const aiRoutes = await generateAIRoutes(surpriseStart, surpriseDest, randomVibe, "", transport);
      setRoutes(aiRoutes);
      setScreen("routes");
      toast.success(`Surprise! ${randomVibe} route to ${surpriseDest} 🎲`);
    } catch (err: any) {
      console.error("Surprise route failed:", err);
      toast.error(err.message || "Surprise failed. Please try again.");
    } finally {
      setIsLoading(false);
    }
  }, [transport]);

  const selectRoute = useCallback((route: RouteOption) => {
    setSelectedRoute(route);
    setScreen("preview");
  }, []);

  return (
    <div className="max-w-md mx-auto min-h-screen bg-background">
      <AnimatePresence mode="wait">
        {screen === "input" && (
          <InputScreen
            key="input"
            startLocation={startLocation}
            onStartChange={setStartLocation}
            destination={destination}
            onDestinationChange={setDestination}
            vibe={vibe}
            onVibeSelect={setVibe}
            customVibe={customVibe}
            onCustomVibeChange={setCustomVibe}
            transport={transport}
            onTransportSelect={setTransport}
            onGenerate={generate}
            onSurpriseMe={surpriseMe}
            isLoading={isLoading}
            onDetectLocation={detectLocation}
          />
        )}
        {screen === "routes" && (
          <RoutesScreen
            key="routes"
            routes={routes}
            vibe={vibe}
            onBack={() => setScreen("input")}
            onSelectRoute={selectRoute}
          />
        )}
        {screen === "preview" && selectedRoute && (
          <PreviewScreen
            key="preview"
            route={selectedRoute}
            onBack={() => setScreen("routes")}
          />
        )}
      </AnimatePresence>
    </div>
  );
}
