import { motion } from "framer-motion";
import { ArrowLeft } from "lucide-react";
import RouteCard from "./RouteCard";
import { RouteOption, Vibe } from "@/lib/types";

interface RoutesScreenProps {
  routes: RouteOption[];
  vibe: Vibe | null;
  onBack: () => void;
  onSelectRoute: (route: RouteOption) => void;
}

export default function RoutesScreen({ routes, vibe, onBack, onSelectRoute }: RoutesScreenProps) {
  return (
    <motion.div
      initial={{ opacity: 0, x: 50 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: -50 }}
      className="flex flex-col min-h-screen p-4 pb-8"
    >
      {/* Header */}
      <div className="flex items-center gap-3 pt-6 pb-4">
        <button onClick={onBack} className="p-2 rounded-xl hover:bg-secondary transition-colors">
          <ArrowLeft className="w-5 h-5 text-foreground" />
        </button>
        <div>
          <h2 className="font-display text-xl font-bold text-foreground">Your Routes</h2>
          <p className="text-xs text-muted-foreground">
            {routes.length} {vibe} routes found
          </p>
        </div>
      </div>

      {/* Routes */}
      <div className="space-y-3 flex-1">
        {routes.map((route, i) => (
          <RouteCard key={route.id} route={route} index={i} onSelect={() => onSelectRoute(route)} />
        ))}
      </div>
    </motion.div>
  );
}
