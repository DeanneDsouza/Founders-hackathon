import { motion } from "framer-motion";
import { ArrowLeft, ExternalLink, Copy, Share2, Clock, Ruler, MapPin, Music } from "lucide-react";
import { RouteOption } from "@/lib/types";
import MapView from "./MapView";
import { toast } from "sonner";

interface PreviewScreenProps {
  route: RouteOption;
  onBack: () => void;
}

export default function PreviewScreen({ route, onBack }: PreviewScreenProps) {
  const handleOpenMaps = () => {
    const start = route.coordinates[0];
    const end = route.coordinates[route.coordinates.length - 1];
    const url = `https://www.google.com/maps/dir/${start[0]},${start[1]}/${end[0]},${end[1]}`;
    window.open(url, "_blank");
  };

  const handleCopyLink = () => {
    const start = route.coordinates[0];
    const end = route.coordinates[route.coordinates.length - 1];
    const url = `https://www.google.com/maps/dir/${start[0]},${start[1]}/${end[0]},${end[1]}`;
    navigator.clipboard.writeText(url);
    toast.success("Route link copied!");
  };

  const handleShare = async () => {
    if (navigator.share) {
      await navigator.share({
        title: route.name,
        text: route.description,
        url: window.location.href,
      });
    } else {
      handleCopyLink();
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, x: 50 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: -50 }}
      className="flex flex-col min-h-screen"
    >
      {/* Map */}
      <div className="relative">
        <MapView coordinates={route.coordinates} attractions={route.attractions} className="h-[45vh]" />
        <button
          onClick={onBack}
          className="absolute top-4 left-4 z-[1000] p-2.5 rounded-xl bg-background/80 backdrop-blur-sm border border-border/50"
        >
          <ArrowLeft className="w-5 h-5 text-foreground" />
        </button>
      </div>

      {/* Details */}
      <div className="flex-1 p-4 space-y-4 -mt-6 relative z-10">
        <div className="glass-card p-4 space-y-4">
          <h2 className="font-display text-xl font-bold text-foreground">{route.name}</h2>
          <p className="text-sm text-muted-foreground leading-relaxed">{route.description}</p>

          <div className="flex items-center gap-4 text-sm text-muted-foreground">
            <span className="flex items-center gap-1.5">
              <Clock className="w-4 h-4 text-primary" /> {route.duration}
            </span>
            <span className="flex items-center gap-1.5">
              <Ruler className="w-4 h-4 text-primary" /> {route.distance}
            </span>
          </div>

          {/* Attractions */}
          <div className="space-y-2">
            <h4 className="text-xs font-medium text-muted-foreground uppercase tracking-wider">Attractions</h4>
            <div className="flex flex-wrap gap-2">
              {route.attractions.map((a) => (
                <span key={a} className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-secondary text-xs text-secondary-foreground">
                  <MapPin className="w-3 h-3" /> {a}
                </span>
              ))}
            </div>
          </div>

          {/* Vibe Explanation */}
          <div className="p-3 rounded-lg bg-primary/5 border border-primary/10">
            <p className="text-sm text-primary/80">🧠 {route.vibeExplanation}</p>
          </div>

          {/* Playlist */}
          <div className="flex items-center gap-3 p-3 rounded-lg bg-accent/10 border border-accent/20">
            <Music className="w-5 h-5 text-accent" />
            <div>
              <p className="text-sm font-medium text-foreground">{route.playlist.emoji} {route.playlist.name}</p>
              <p className="text-xs text-muted-foreground">{route.playlist.genre}</p>
            </div>
          </div>
        </div>

        {/* Actions */}
        <div className="space-y-2 pb-6">
          <motion.button whileTap={{ scale: 0.98 }} className="btn-primary flex items-center justify-center gap-2" onClick={handleOpenMaps}>
            <ExternalLink className="w-4 h-4" /> Open in Google Maps
          </motion.button>
          <div className="grid grid-cols-2 gap-2">
            <motion.button whileTap={{ scale: 0.98 }} className="btn-secondary flex items-center justify-center gap-2" onClick={handleCopyLink}>
              <Copy className="w-4 h-4" /> Copy Link
            </motion.button>
            <motion.button whileTap={{ scale: 0.98 }} className="btn-secondary flex items-center justify-center gap-2" onClick={handleShare}>
              <Share2 className="w-4 h-4" /> Share
            </motion.button>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
