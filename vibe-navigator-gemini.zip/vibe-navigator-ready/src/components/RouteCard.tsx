import { motion } from "framer-motion";
import { RouteOption } from "@/lib/types";
import { Clock, Ruler, MapPin, Music } from "lucide-react";

interface RouteCardProps {
  route: RouteOption;
  index: number;
  onSelect: () => void;
}

export default function RouteCard({ route, index, onSelect }: RouteCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.1 }}
      className="glass-card p-4 space-y-3 cursor-pointer active:scale-[0.98] transition-transform"
      onClick={onSelect}
    >
      <div className="flex items-start justify-between">
        <div className="space-y-1 flex-1">
          <h3 className="font-display font-semibold text-foreground">{route.name}</h3>
          <p className="text-sm text-muted-foreground leading-relaxed">{route.description}</p>
        </div>
      </div>

      <div className="flex items-center gap-4 text-xs text-muted-foreground">
        <span className="flex items-center gap-1">
          <Clock className="w-3.5 h-3.5 text-primary" /> {route.duration}
        </span>
        <span className="flex items-center gap-1">
          <Ruler className="w-3.5 h-3.5 text-primary" /> {route.distance}
        </span>
        <span className="flex items-center gap-1">
          <MapPin className="w-3.5 h-3.5 text-primary" /> {route.attractions.length} stops
        </span>
      </div>

      <div className="flex items-center gap-2 px-3 py-2 rounded-lg bg-secondary/50 text-xs">
        <Music className="w-3.5 h-3.5 text-accent" />
        <span className="text-muted-foreground">
          {route.playlist.emoji} {route.playlist.name} · {route.playlist.genre}
        </span>
      </div>

      <div className="p-3 rounded-lg bg-primary/5 border border-primary/10">
        <p className="text-xs text-primary/80 italic">🧠 {route.vibeExplanation}</p>
      </div>
    </motion.div>
  );
}
