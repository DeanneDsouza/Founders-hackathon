import { motion } from "framer-motion";
import { MapPin, Navigation, Shuffle } from "lucide-react";
import VibePicker from "./VibePicker";
import TransportPicker from "./TransportPicker";
import { Vibe, Transport } from "@/lib/types";

interface InputScreenProps {
  startLocation: string;
  onStartChange: (val: string) => void;
  destination: string;
  onDestinationChange: (val: string) => void;
  vibe: Vibe | null;
  onVibeSelect: (v: Vibe) => void;
  customVibe: string;
  onCustomVibeChange: (val: string) => void;
  transport: Transport;
  onTransportSelect: (t: Transport) => void;
  onGenerate: () => void;
  onSurpriseMe: () => void;
  isLoading: boolean;
  onDetectLocation: () => void;
}

export default function InputScreen({
  startLocation, onStartChange,
  destination, onDestinationChange,
  vibe, onVibeSelect,
  customVibe, onCustomVibeChange,
  transport, onTransportSelect,
  onGenerate, onSurpriseMe,
  isLoading, onDetectLocation,
}: InputScreenProps) {
  const canGenerate = startLocation.trim() && destination.trim() && (vibe || customVibe.trim());

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="flex flex-col min-h-screen p-4 pb-8"
    >
      {/* Header */}
      <div className="pt-8 pb-6 text-center">
        <motion.h1
          initial={{ y: -20 }}
          animate={{ y: 0 }}
          className="font-display text-3xl font-bold text-foreground"
        >
          Vibe<span className="text-primary">Route</span>
        </motion.h1>
        <p className="text-sm text-muted-foreground mt-1">Navigate by feeling, not just distance</p>
      </div>

      <div className="space-y-5 flex-1">
        {/* Start Location */}
        <div className="space-y-2">
          <label className="text-xs font-medium text-muted-foreground uppercase tracking-wider">
            📍 Starting point
          </label>
          <div className="relative">
            <input
              className="input-field pr-10"
              placeholder="Enter starting location..."
              value={startLocation}
              onChange={(e) => onStartChange(e.target.value)}
            />
            <button
              onClick={onDetectLocation}
              className="absolute right-2 top-1/2 -translate-y-1/2 p-1.5 rounded-lg hover:bg-primary/10 transition-colors"
            >
              <Navigation className="w-4 h-4 text-primary" />
            </button>
          </div>
        </div>

        {/* Destination */}
        <div className="space-y-2">
          <label className="text-xs font-medium text-muted-foreground uppercase tracking-wider">
            🎯 Destination
          </label>
          <div className="relative">
            <input
              className="input-field"
              placeholder="Where are you heading?"
              value={destination}
              onChange={(e) => onDestinationChange(e.target.value)}
            />
            <MapPin className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          </div>
        </div>

        {/* Vibe */}
        <VibePicker
          selected={vibe}
          onSelect={onVibeSelect}
          customVibe={customVibe}
          onCustomVibeChange={onCustomVibeChange}
        />

        {/* Transport */}
        <TransportPicker selected={transport} onSelect={onTransportSelect} />
      </div>

      {/* Actions */}
      <div className="space-y-3 pt-6">
        <motion.button
          whileTap={{ scale: 0.98 }}
          className="btn-primary"
          disabled={!canGenerate || isLoading}
          onClick={onGenerate}
        >
          {isLoading ? (
            <span className="flex items-center justify-center gap-2">
              <span className="w-4 h-4 border-2 border-primary-foreground/30 border-t-primary-foreground rounded-full animate-spin" />
              Finding routes...
            </span>
          ) : (
            "Find My Vibe Route"
          )}
        </motion.button>

        <motion.button
          whileTap={{ scale: 0.98 }}
          className="btn-secondary flex items-center justify-center gap-2"
          onClick={onSurpriseMe}
          disabled={isLoading}
        >
          <Shuffle className="w-4 h-4" />
          🎲 Surprise Me
        </motion.button>
      </div>
    </motion.div>
  );
}
