import { useEffect, useRef } from "react";
import L from "leaflet";

interface MapViewProps {
  coordinates: [number, number][];
  attractions?: string[];
  className?: string;
}

export default function MapView({ coordinates, attractions = [], className = "" }: MapViewProps) {
  const mapRef = useRef<HTMLDivElement>(null);
  const mapInstance = useRef<L.Map | null>(null);

  useEffect(() => {
    if (!mapRef.current || coordinates.length === 0) return;

    if (mapInstance.current) {
      mapInstance.current.remove();
    }

    const map = L.map(mapRef.current, {
      zoomControl: true,
      attributionControl: false,
    });

    L.tileLayer("https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png", {
      maxZoom: 19,
    }).addTo(map);

    // Draw route
    const latlngs = coordinates.map(([lat, lng]) => [lat, lng] as L.LatLngTuple);
    const polyline = L.polyline(latlngs, {
      color: "#2dd4bf",
      weight: 4,
      opacity: 0.8,
      smoothFactor: 1,
    }).addTo(map);

    // Start marker
    const startIcon = L.divIcon({
      className: "",
      html: `<div style="width:14px;height:14px;background:#2dd4bf;border-radius:50%;border:3px solid #0f172a;box-shadow:0 0 10px rgba(45,212,191,0.5)"></div>`,
      iconSize: [14, 14],
      iconAnchor: [7, 7],
    });
    L.marker(latlngs[0], { icon: startIcon }).addTo(map);

    // End marker
    const endIcon = L.divIcon({
      className: "",
      html: `<div style="width:14px;height:14px;background:#a78bfa;border-radius:50%;border:3px solid #0f172a;box-shadow:0 0 10px rgba(167,139,250,0.5)"></div>`,
      iconSize: [14, 14],
      iconAnchor: [7, 7],
    });
    L.marker(latlngs[latlngs.length - 1], { icon: endIcon }).addTo(map);

    // Attraction markers
    const step = Math.max(1, Math.floor(latlngs.length / (attractions.length + 1)));
    attractions.forEach((name, i) => {
      const idx = Math.min((i + 1) * step, latlngs.length - 1);
      const icon = L.divIcon({
        className: "",
        html: `<div style="width:8px;height:8px;background:#f59e0b;border-radius:50%;border:2px solid #0f172a"></div>`,
        iconSize: [8, 8],
        iconAnchor: [4, 4],
      });
      L.marker(latlngs[idx], { icon }).bindTooltip(name, {
        className: "leaflet-tooltip-custom",
        direction: "top",
        offset: [0, -8],
      }).addTo(map);
    });

    map.fitBounds(polyline.getBounds(), { padding: [40, 40] });
    mapInstance.current = map;

    return () => {
      map.remove();
      mapInstance.current = null;
    };
  }, [coordinates, attractions]);

  return <div ref={mapRef} className={`w-full ${className}`} />;
}
