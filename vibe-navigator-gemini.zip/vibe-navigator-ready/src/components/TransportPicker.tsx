import { motion } from "framer-motion";
import { Transport } from "@/lib/types";

const modes: { id: Transport; label: string; emoji: string }[] = [
  { id: "walking", label: "Walk", emoji: "🚶" },
  { id: "bike", label: "Bike", emoji: "🚴" },
  { id: "car", label: "Car", emoji: "🚗" },
  { id: "transit", label: "Transit", emoji: "🚌" },
];

interface TransportPickerProps {
  selected: Transport;
  onSelect: (t: Transport) => void;
}

export default function TransportPicker({ selected, onSelect }: TransportPickerProps) {
  return (
    <div className="space-y-3">
      <label className="text-xs font-medium text-muted-foreground uppercase tracking-wider">
        🚗 Transport mode
      </label>
      <div className="grid grid-cols-4 gap-2">
        {modes.map((m) => (
          <motion.button
            key={m.id}
            whileTap={{ scale: 0.95 }}
            className={`transport-btn ${selected === m.id ? "active" : ""}`}
            onClick={() => onSelect(m.id)}
          >
            <span className="text-xl">{m.emoji}</span>
            <span>{m.label}</span>
          </motion.button>
        ))}
      </div>
    </div>
  );
}
