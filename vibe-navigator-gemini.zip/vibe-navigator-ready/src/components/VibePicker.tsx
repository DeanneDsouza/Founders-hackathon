import { motion } from "framer-motion";
import { Vibe } from "@/lib/types";

const vibes: { id: Vibe; label: string; emoji: string }[] = [
  { id: "calm", label: "Calm", emoji: "🌿" },
  { id: "scenic", label: "Scenic", emoji: "🌄" },
  { id: "fast", label: "Fast", emoji: "⚡" },
  { id: "fun", label: "Fun", emoji: "🎉" },
  { id: "quiet", label: "Quiet", emoji: "🤫" },
];

interface VibePickerProps {
  selected: Vibe | null;
  onSelect: (vibe: Vibe) => void;
  customVibe: string;
  onCustomVibeChange: (val: string) => void;
}

export default function VibePicker({ selected, onSelect, customVibe, onCustomVibeChange }: VibePickerProps) {
  return (
    <div className="space-y-3">
      <label className="text-xs font-medium text-muted-foreground uppercase tracking-wider">
        🎭 Select your vibe
      </label>
      <div className="flex flex-wrap gap-2">
        {vibes.map((v) => (
          <motion.button
            key={v.id}
            whileTap={{ scale: 0.95 }}
            className={`vibe-chip ${selected === v.id ? "active" : ""}`}
            onClick={() => onSelect(v.id)}
          >
            {v.emoji} {v.label}
          </motion.button>
        ))}
      </div>
      <input
        type="text"
        className="input-field"
        placeholder="Or describe your vibe..."
        value={customVibe}
        onChange={(e) => onCustomVibeChange(e.target.value)}
      />
    </div>
  );
}
